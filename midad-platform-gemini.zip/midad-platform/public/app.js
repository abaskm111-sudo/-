'use strict';

const state = { user: null, reports: [], selectedReport: null, authMode: 'login', returnTo: null, toastTimer: null };
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'same-origin',
    headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) },
    ...options
  });
  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await response.json() : await response.blob();
  if (!response.ok) throw new Error(data?.error || 'حدث خطأ غير متوقع.');
  return data;
}
function toast(message) {
  const el = $('#toast'); el.textContent = message; el.classList.add('show');
  clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}
function markdownToHtml(markdown) {
  const lines = String(markdown || '').replace(/\r/g, '').split('\n');
  const out = []; let inList = false;
  const closeList = () => { if (inList) { out.push('</ul>'); inList = false; } };
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) { closeList(); continue; }
    const heading = line.match(/^(#{1,3})\s+(.+)$/);
    if (heading) { closeList(); const level = heading[1].length; out.push(`<h${level}>${inlineMarkdown(heading[2])}</h${level}>`); continue; }
    const bullet = line.match(/^[-*•]\s+(.+)$/);
    if (bullet) { if (!inList) { out.push('<ul>'); inList = true; } out.push(`<li>${inlineMarkdown(bullet[1])}</li>`); continue; }
    closeList();
    if (/^\|.*\|$/.test(line)) { out.push(`<p>${inlineMarkdown(line.replace(/\|/g, ' · '))}</p>`); continue; }
    out.push(`<p>${inlineMarkdown(line)}</p>`);
  }
  closeList(); return out.join('\n');
}
function inlineMarkdown(text) {
  let safe = escapeHtml(text);
  safe = safe.replace(/`([^`]+)`/g, '<code>$1</code>');
  safe = safe.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  safe = safe.replace(/\*(.*?)\*/g, '<em>$1</em>');
  return safe;
}
function dateLabel(value, time = false) {
  if (!value) return '—';
  const date = new Date(value.includes('T') ? value : value.replace(' ', 'T') + 'Z');
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString('ar-IQ', time ? { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' } : { day: 'numeric', month: 'short', year: 'numeric' });
}
function showAuth(mode = 'login', returnTo = null) {
  state.authMode = mode; state.returnTo = returnTo;
  $('#authModal').classList.remove('hidden');
  $('#authError').classList.add('hidden');
  $('#authNameWrap').classList.toggle('hidden', mode !== 'register');
  $('#authName').required = mode === 'register';
  $('#authPassword').autocomplete = mode === 'register' ? 'new-password' : 'current-password';
  $('#authTitle').innerHTML = mode === 'register' ? 'أنشئ حسابك <em>الآن.</em>' : 'مساحتك تبدأ <em>هنا.</em>';
  $('#authSub').textContent = mode === 'register' ? 'افتح مساحة خاصة واحفظ تقاريرك وارجع إليها متى شئت.' : 'سجّل دخولك للوصول إلى تقاريرك المحفوظة.';
  $('#authSubmit span').textContent = mode === 'register' ? 'إنشاء حساب' : 'تسجيل الدخول';
  $('#authSwitchText').textContent = mode === 'register' ? 'لديك حساب بالفعل؟' : 'ليس لديك حساب؟';
  $('#authSwitch').textContent = mode === 'register' ? 'تسجيل الدخول' : 'إنشاء حساب جديد';
}
function closeAuth() { $('#authModal').classList.add('hidden'); }
function setUser(user) {
  state.user = user;
  $('#profileName').textContent = user ? user.name : 'زائر مِداد';
  $('#profileRole').textContent = user?.role === 'admin' ? 'مالك المنصة' : user ? 'مساحة الطالب' : 'مساحة الطالب';
  $('#avatarInitial').textContent = user ? [...user.name][0] : 'م';
  $('#authNav').classList.toggle('hidden', Boolean(user));
  $('#adminNav').classList.toggle('hidden', user?.role !== 'admin');
  if (user?.role !== 'admin' && $('#page-admin').classList.contains('active')) navigate('overview');
}
function navigate(page) {
  if (page === 'create' && !state.user) { showAuth('login', 'create'); return; }
  if (page === 'admin' && state.user?.role !== 'admin') { toast('هذه الصفحة متاحة لمدير المنصة فقط.'); return; }
  $$('.page').forEach(el => el.classList.toggle('active', el.id === `page-${page}`));
  $$('.nav-item[data-page]').forEach(el => el.classList.toggle('active', el.dataset.page === page));
  if (page === 'library') loadReports();
  if (page === 'admin') loadAdmin();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
async function loadReports() {
  if (!state.user) { state.reports = []; renderLibrary(); return; }
  try { const data = await api('/api/reports'); state.reports = data.reports || []; renderLibrary(); updateStudentMetrics(); }
  catch (err) { toast(err.message); }
}
function updateStudentMetrics() {
  $('#myReportCount').textContent = String(state.reports.length).padStart(2, '0');
  $('#lastActivity').textContent = state.reports[0] ? dateLabel(state.reports[0].createdAt).replace(/\s*٢٠٢\d/, '') : '—';
}
function renderLibrary() {
  const grid = $('#libraryGrid');
  const q = ($('#reportSearch')?.value || '').trim().toLowerCase();
  const items = state.reports.filter(r => `${r.title} ${r.subject} ${r.reportType}`.toLowerCase().includes(q));
  $('#libraryCount').textContent = `${items.length} تقرير`;
  if (!state.user) {
    grid.innerHTML = `<div class="empty-state"><span>◎</span><b>سجّل الدخول للوصول إلى مكتبتك</b><p>ستحفظ مِداد تقاريرك داخل حسابك.</p><button class="primary-button" data-action="login">تسجيل الدخول <b>↗</b></button></div>`; return;
  }
  if (!items.length) {
    grid.innerHTML = `<div class="empty-state"><span>▤</span><b>${q ? 'لا توجد نتائج مطابقة' : 'مكتبتك بانتظار أول تقرير'}</b><p>${q ? 'جرّب البحث بكلمات مختلفة.' : 'أنشئ تقريرك الأول ليظهر هنا.'}</p><button class="primary-button" data-page="create">ابدأ الآن <b>↗</b></button></div>`; return;
  }
  grid.innerHTML = items.map(r => `<article class="report-card"><div class="report-card-top"><span class="report-type">${escapeHtml(r.reportType)}</span><time>${escapeHtml(dateLabel(r.createdAt))}</time></div><h3>${escapeHtml(r.title)}</h3><p>${escapeHtml(r.subject)}</p><div class="report-card-foot"><button data-action="open-report" data-id="${r.id}">فتح التقرير ↗</button><button class="delete-report" data-action="delete-report" data-id="${r.id}">حذف</button></div></article>`).join('');
}
async function openReport(id) {
  try {
    const data = await api(`/api/reports/${id}`); state.selectedReport = data.report;
    showResult(data.report); navigate('create');
  } catch (err) { toast(err.message); }
}
function showResult(report) {
  $('#resultTitle').textContent = report.title;
  $('#reportPreview').innerHTML = markdownToHtml(report.content);
  $('#resultPanel').classList.remove('hidden');
  $('#resultPanel').dataset.reportId = report.id;
  $('#resultPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
}
async function deleteReport(id) {
  if (!confirm('هل تريد حذف هذا التقرير نهائياً؟')) return;
  try { await api(`/api/reports/${id}`, { method: 'DELETE' }); state.reports = state.reports.filter(r => r.id !== Number(id)); renderLibrary(); updateStudentMetrics(); toast('تم حذف التقرير.'); }
  catch (err) { toast(err.message); }
}
async function generateReport(event) {
  event.preventDefault();
  if (!state.user) { showAuth('login', 'create'); return; }
  const button = $('#generateButton');
  const payload = {
    title: $('#reportTitle').value.trim(), subject: $('#reportSubject').value.trim(),
    reportType: $('#reportType').value, language: $('#reportLanguage').value,
    length: $('input[name="length"]:checked')?.value || 'متوسط', details: $('#reportDetails').value.trim()
  };
  button.disabled = true; button.querySelector('.button-label').textContent = 'مِداد يكتب تقريرك الآن...'; button.querySelector('b').textContent = '◌';
  $('#resultPanel').classList.add('hidden');
  try {
    const data = await api('/api/reports', { method: 'POST', body: JSON.stringify(payload) });
    state.selectedReport = data.report; showResult(data.report); await loadReports(); toast('تم إنشاء التقرير وحفظه في مكتبتك.');
  } catch (err) { toast(err.message); }
  finally { button.disabled = false; button.querySelector('.button-label').textContent = 'إنشاء التقرير بالذكاء الاصطناعي'; button.querySelector('b').textContent = '✦'; }
}
async function downloadDocx() {
  const report = state.selectedReport; if (!report) return toast('افتح تقريراً أولاً.');
  try {
    const response = await fetch(`/api/reports/${report.id}/docx`, { credentials: 'same-origin' });
    if (!response.ok) { const e = await response.json().catch(() => ({})); throw new Error(e.error || 'تعذر تجهيز ملف Word.'); }
    const blob = await response.blob(); const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = `Midad-Report-${report.id}.docx`; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url); toast('تم تجهيز ملف Word.');
  } catch (err) { toast(err.message); }
}
function downloadPdf() {
  const report = state.selectedReport; if (!report) return toast('افتح تقريراً أولاً.');
  const win = window.open('', '_blank');
  if (!win) return toast('اسمح بالنوافذ المنبثقة حتى تتمكن من حفظ PDF.');
  const body = markdownToHtml(report.content);
  win.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${escapeHtml(report.title)}</title><style>@page{size:A4;margin:18mm}*{box-sizing:border-box}body{font-family:Tahoma,Arial,sans-serif;color:#202a40;line-height:1.95;font-size:12pt;margin:0;direction:rtl}header{border-bottom:2px solid #7770c9;padding-bottom:13px;margin-bottom:24px}h1{font-size:21pt;color:#393c71;margin:0 0 8px}header p{font-size:9pt;color:#64708a;margin:0}h1,h2,h3{break-after:avoid;color:#373d72}h2{font-size:16pt;margin-top:25px}h3{font-size:13pt;margin-top:20px}p{margin:0 0 9px;text-align:justify}ul{padding-right:25px}li{margin:5px 0}strong{color:#262e57}footer{border-top:1px solid #ddd;margin-top:35px;padding-top:10px;text-align:center;font-size:8pt;color:#8991a4}@media screen{body{max-width:800px;margin:25px auto;padding:35px;background:white;box-shadow:0 4px 35px #ccd}}@media print{body{max-width:none;padding:0}}</style></head><body><header><h1>${escapeHtml(report.title)}</h1><p>${escapeHtml(report.reportType)} · ${escapeHtml(report.language)} · مِداد</p></header><main>${body}</main><footer>تم إعداد هذا المستند عبر منصة مِداد — تطوير عباس كريم جاسم</footer><script>window.onload=()=>setTimeout(()=>window.print(),350);<\/script></body></html>`);
  win.document.close();
}
async function copyReport() {
  if (!state.selectedReport) return toast('لا يوجد تقرير لنسخه.');
  try { await navigator.clipboard.writeText(state.selectedReport.content); toast('تم نسخ محتوى التقرير.'); }
  catch { toast('لم يتمكن المتصفح من النسخ.'); }
}
async function loadAdmin() {
  try {
    const [statsData, settingsData] = await Promise.all([api('/api/admin/stats'), api('/api/admin/settings')]);
    const s = statsData.stats;
    const cards = [s.users, s.reports, s.visits, s.todayVisits];
    const labels = ['إجمالي المستخدمين', 'إجمالي التقارير', 'زيارات فريدة', 'زيارات اليوم'];
    const foot = [`${s.todayUsers} حساب جديد اليوم`, 'تقرير محفوظ في المنصة', 'كل متصفح مرة يومياً', `${s.todayReports} تقرير أُنشئ اليوم`];
    $('#adminStats').innerHTML = cards.map((n, i) => `<div class="admin-stat"><small>${labels[i]}</small><strong>${Number(n).toLocaleString('en-US')}</strong><span>${foot[i]}</span></div>`).join('');
    $('#aiStatus').textContent = statsData.aiConfigured ? 'مهيأ' : 'غير مهيأ';
    $('#aiStatus').className = `service-state ${statsData.aiConfigured ? 'good' : ''}`;
    $('#aiStatusText').textContent = statsData.aiConfigured ? `API مهيأ · ${escapeHtml(statsData.aiModel)}` : 'أضف مفتاح API في ملف .env للخادم';
    $('#recentUsers').innerHTML = statsData.recentUsers.length ? statsData.recentUsers.map(u => `<div class="mini-table-row"><div><b>${escapeHtml(u.name)}</b><small>${escapeHtml(u.email)}</small></div><span>${u.role === 'admin' ? 'مدير' : 'طالب'}</span></div>`).join('') : '<div class="table-empty">لا يوجد مستخدمون بعد.</div>';
    $('#recentReports').innerHTML = statsData.recentReports.length ? statsData.recentReports.map(r => `<div class="mini-table-row"><div><b>${escapeHtml(r.title)}</b><small>${escapeHtml(r.user_name)} · ${escapeHtml(r.email)}</small></div><span>${escapeHtml(dateLabel(r.created_at))}</span></div>`).join('') : '<div class="table-empty">لا توجد تقارير بعد.</div>';
    $('#adsEnabled').checked = settingsData.adsEnabled; $('#adsenseClient').value = settingsData.adsenseClient || ''; $('#adsenseSlot').value = settingsData.adsenseSlot || ''; $('#admobAppId').value = settingsData.admobAppId || ''; $('#admobBannerId').value = settingsData.admobBannerId || '';
  } catch (err) { toast(err.message); }
}
async function saveAds(event) {
  event.preventDefault();
  try {
    await api('/api/admin/settings', { method: 'POST', body: JSON.stringify({ adsEnabled: $('#adsEnabled').checked, adsenseClient: $('#adsenseClient').value.trim(), adsenseSlot: $('#adsenseSlot').value.trim(), admobAppId: $('#admobAppId').value.trim(), admobBannerId: $('#admobBannerId').value.trim() }) });
    toast('تم حفظ إعدادات الإعلانات.'); await loadAdsConfig();
  } catch (err) { toast(err.message); }
}
async function loadAdsConfig() {
  try {
    const config = await api('/api/public-config');
    if (!config.adsenseEnabled) return;
    const slot = $('#adSlot'); slot.classList.remove('hidden');
    const ins = $('.adsbygoogle', slot); ins.setAttribute('data-ad-client', config.adsenseClient); ins.setAttribute('data-ad-slot', config.adsenseSlot);
    if (!document.querySelector('script[data-midad-ads]')) {
      const script = document.createElement('script'); script.async = true; script.crossOrigin = 'anonymous'; script.dataset.midadAds = '1';
      script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${encodeURIComponent(config.adsenseClient)}`; document.head.appendChild(script);
      script.onload = () => { try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) { console.warn('AdSense slot unavailable', e); } };
    } else { try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) { console.warn(e); } }
  } catch (e) { console.warn('Ads configuration unavailable', e); }
}
function visitTracking() {
  let id = localStorage.getItem('midad_visitor_id');
  if (!id) { id = crypto.randomUUID ? crypto.randomUUID() : `v-${Date.now()}-${Math.random().toString(36).slice(2)}`; localStorage.setItem('midad_visitor_id', id); }
  api('/api/visit', { method: 'POST', body: JSON.stringify({ visitorId: id }) }).catch(() => {});
}

// Navigation and shared interactions.
document.addEventListener('click', async event => {
  const pageButton = event.target.closest('[data-page]');
  if (pageButton) { event.preventDefault(); navigate(pageButton.dataset.page); return; }
  const action = event.target.closest('[data-action]');
  if (action) {
    if (action.dataset.action === 'login') showAuth('login');
    if (action.dataset.action === 'open-report') openReport(action.dataset.id);
    if (action.dataset.action === 'delete-report') deleteReport(action.dataset.id);
  }
});
$('#authNav').addEventListener('click', () => showAuth('login'));
$('#profileButton').addEventListener('click', async () => {
  if (!state.user) return showAuth('login');
  if (confirm(`أنت مسجل باسم ${state.user.name}. هل تريد تسجيل الخروج؟`)) {
    try { await api('/api/auth/logout', { method: 'POST' }); setUser(null); state.reports = []; navigate('overview'); toast('تم تسجيل الخروج.'); }
    catch (err) { toast(err.message); }
  }
});
$('#closeAuth').addEventListener('click', closeAuth);
$('#authModal').addEventListener('click', e => { if (e.target === $('#authModal')) closeAuth(); });
$('#authSwitch').addEventListener('click', () => showAuth(state.authMode === 'login' ? 'register' : 'login', state.returnTo));
$('#authForm').addEventListener('submit', async event => {
  event.preventDefault(); $('#authError').classList.add('hidden');
  const mode = state.authMode;
  const payload = { email: $('#authEmail').value.trim(), password: $('#authPassword').value };
  if (mode === 'register') payload.name = $('#authName').value.trim();
  const submit = $('#authSubmit'); submit.disabled = true;
  try {
    const data = await api(`/api/auth/${mode}`, { method: 'POST', body: JSON.stringify(payload) });
    setUser(data.user); closeAuth(); await loadReports(); toast(mode === 'register' ? 'تم إنشاء حسابك بنجاح.' : 'أهلاً بعودتك إلى مِداد.');
    const destination = state.returnTo || 'overview'; state.returnTo = null; navigate(destination);
  } catch (err) { $('#authError').textContent = err.message; $('#authError').classList.remove('hidden'); }
  finally { submit.disabled = false; }
});
$('#reportForm').addEventListener('submit', generateReport);
$('#lengthChoice').addEventListener('change', () => $$('.length-option').forEach(el => el.classList.toggle('selected', $('input', el).checked)));
$('#downloadDocx').addEventListener('click', downloadDocx);
$('#downloadPdf').addEventListener('click', downloadPdf);
$('#copyReport').addEventListener('click', copyReport);
$('#reportSearch').addEventListener('input', renderLibrary);
$('#refreshAdmin').addEventListener('click', loadAdmin);
$('#testGemini').addEventListener('click', async () => {
  const button = $('#testGemini');
  button.disabled = true; button.textContent = 'جارٍ اختبار Gemini...';
  try {
    const result = await api('/api/admin/ai-test', { method: 'POST', body: JSON.stringify({}) });
    toast(`اتصال Gemini ناجح · ${result.model} · ${result.response}`);
    await loadAdmin();
  } catch (err) { toast(`فشل اختبار Gemini: ${err.message}`); }
  finally { button.disabled = false; button.textContent = 'اختبار اتصال Gemini ↻'; }
});
$('#openAllUsers').addEventListener('click', async () => {
  try { const data = await api('/api/admin/users'); $('#allUsersTable').innerHTML = data.users.map(u => `<div class="mini-table-row"><div><b>${escapeHtml(u.name)} · ${escapeHtml(u.role === 'admin' ? 'مدير' : 'طالب')}</b><small>${escapeHtml(u.email)} · انضم ${escapeHtml(dateLabel(u.created_at))}</small></div><span>${u.reports_count} تقرير</span></div>`).join('') || '<div class="table-empty">لا يوجد مستخدمون.</div>'; $('#allUsersPanel').classList.remove('hidden'); $('#allUsersPanel').scrollIntoView({ behavior: 'smooth' }); } catch (err) { toast(err.message); }
});
$('#openAllReports').addEventListener('click', async () => {
  try { const data = await api('/api/admin/reports'); $('#allReportsTable').innerHTML = data.reports.map(r => `<div class="mini-table-row"><div><b>${escapeHtml(r.title)}</b><small>${escapeHtml(r.user_name)} · ${escapeHtml(r.email)} · ${escapeHtml(r.report_type)} · ${escapeHtml(dateLabel(r.created_at))}</small></div><span>${escapeHtml(r.language)}</span></div>`).join('') || '<div class="table-empty">لا توجد تقارير.</div>'; $('#allReportsPanel').classList.remove('hidden'); $('#allReportsPanel').scrollIntoView({ behavior: 'smooth' }); } catch (err) { toast(err.message); }
});
document.addEventListener('click', e => { const close = e.target.closest('[data-close-panel]'); if (close) $('#' + close.dataset.closePanel).classList.add('hidden'); });
$('#adsForm').addEventListener('submit', saveAds);
$('#themeHint').addEventListener('click', () => toast('مِداد — مساحة كتابة بتصميم ثلاثي الأبعاد.'));

(async function init() {
  visitTracking(); loadAdsConfig();
  try { const data = await api('/api/me'); setUser(data.user); await loadReports(); }
  catch { setUser(null); updateStudentMetrics(); }
})();
